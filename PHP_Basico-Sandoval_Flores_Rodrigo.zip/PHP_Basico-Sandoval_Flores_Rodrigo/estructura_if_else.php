<?php 
	// Sentencia if else
	// Estructura para validar un valor de una forma u otra
	
	$mivalor=true;

	if($mivalor){
		echo "Es verdadero";
	}else{
		echo "Es falso";
	}
	echo "<br>";
	echo "<hr>";	
	$valor1=5;
	$valor2=10;

	if ($valor1 > $valor2) {
		echo "Es verdadero";
	} else {
		echo "Es falso";
	}
	echo "<br>";
	echo "<hr>";

	// Un break es el if dara error en PHP 7

	
?>