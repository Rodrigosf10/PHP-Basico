<?php
	// Este es un comentario con doble //
	# Este es un comentario con #
	/*Este es un comentario con con /* */

	// Para declara una variable se requiere en PHP se requiere el signo $
	// PHP es un lenguaje de programacion deblmente tipado, eso quiere decir que no requiere declarar el tipo de dato a las variables
	$mivariable = 1; 
	// PHP es un lenguaje interpretado, no compilado
	// No se puede escribir una variable con el mismo nombre y no inician con numero
	$mivariable2 = "nombre";
	$mivariable3 = 1.5;

	//Mostrar informacion
	echo $mivariable;
	echo "<br>";
	print $mivariable2;
	echo "<br>";
	echo $mivariable3;
?>