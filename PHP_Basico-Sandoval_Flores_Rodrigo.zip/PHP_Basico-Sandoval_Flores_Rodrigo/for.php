<?php  
	// FOR es una estructura de repeticion e iteraccitiva, donde necesitas un inicio, final y contador.
	for ($i=0; $i<10; $i++) { 
		// Repeticion del proceso
		echo $i;
		echo "<br>";
	}
	echo "<hr>";
	
	// Tablas
	for ($i=1; $i<11; $i++) { 
		echo "10 x ".$i." = ".$i*10;
		echo "<br>";
	}
	echo "<hr>";
?>